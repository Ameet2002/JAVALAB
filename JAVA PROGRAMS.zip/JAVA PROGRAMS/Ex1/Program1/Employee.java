package Program1;

public class Employee {
    private int empNo;
    private double basicPay;

    public Employee(int empNo) {
        this.empNo = empNo;
    }

    public void setBasicPay(double basicPay) {
        this.basicPay = basicPay;
    }

    public void setBasicPay(int basicPay) {
        this.basicPay = (double) basicPay;
    }

    public void display() {
        System.out.println("Employee Number : " + empNo);
        System.out.println("Basic Pay       : " + basicPay);
    }
}
