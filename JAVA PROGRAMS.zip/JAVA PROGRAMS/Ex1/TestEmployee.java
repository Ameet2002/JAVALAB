import Program1.Employee;

public class TestEmployee {
    public static void main(String[] args) {
        Employee emp1 = new Employee(101);
        emp1.setBasicPay(25000.50);  
        emp1.setBasicPay(25000);

        emp1.display();
    }
}
