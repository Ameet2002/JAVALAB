import java.awt.BorderLayout;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class ImageViewerBean extends JPanel {
   private JLabel imageLabel = new JLabel();


   public ImageViewerBean() {
      this.setLayout(new BorderLayout());
      this.add(this.imageLabel, "Center");
   }


   public void setImage(String var1) {
      ImageIcon var2 = new ImageIcon(var1);
      this.imageLabel.setIcon(var2);
   }
}
