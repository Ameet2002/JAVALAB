import java.awt.*;
import java.awt.event.*;

public class CalculatorApp extends Frame implements ActionListener {
    TextField t1, t2, result;
    Button add, sub, mul, div, clear;

    public CalculatorApp() {
        setLayout(new FlowLayout());

        Label l1 = new Label("Number 1:");
        Label l2 = new Label("Number 2:");
        Label l3 = new Label("Result:");

        t1 = new TextField(10);
        t2 = new TextField(10);
        result = new TextField(10);
        result.setEditable(false);

        add = new Button("+");
        sub = new Button("-");
        mul = new Button("*");
        div = new Button("/");
        clear = new Button("Clear");

        add(l1); add(t1);
        add(l2); add(t2);
        add(l3); add(result);
        add(add); add(sub); add(mul); add(div); add(clear);

        add.addActionListener(this);
        sub.addActionListener(this);
        mul.addActionListener(this);
        div.addActionListener(this);
        clear.addActionListener(this);

        setTitle("Calculator");
        setSize(300, 250);
        setVisible(true);

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                System.exit(0);
            }
        });
    }

    public void actionPerformed(ActionEvent e) {
        try {
            double num1 = Double.parseDouble(t1.getText());
            double num2 = Double.parseDouble(t2.getText());
            double res = 0;

            if (e.getSource() == add)
                res = num1 + num2;
            else if (e.getSource() == sub)
                res = num1 - num2;
            else if (e.getSource() == mul)
                res = num1 * num2;
            else if (e.getSource() == div)
                res = num2 != 0 ? num1 / num2 : Double.NaN;
            else if (e.getSource() == clear) {
                t1.setText("");
                t2.setText("");
                result.setText("");
                return;
            }

            result.setText(String.valueOf(res));
        } catch (NumberFormatException ex) {
            result.setText("Invalid input");
        }
    }

    public static void main(String[] args) {
        new CalculatorApp();
    }
}