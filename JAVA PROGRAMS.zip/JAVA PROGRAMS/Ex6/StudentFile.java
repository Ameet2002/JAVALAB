import java.io.*;
import java.util.Scanner;

public class StudentFile {

    static final String FILE_NAME = "students.txt";

    static void addStudent() {
        try {
            FileWriter fw = new FileWriter(FILE_NAME, true);
            BufferedWriter bw = new BufferedWriter(fw);
            try (Scanner sc = new Scanner(System.in)) {
                System.out.print("Enter Student ID: ");
                String id = sc.nextLine();

                System.out.print("Enter Name: ");
                String name = sc.nextLine();

                System.out.print("Enter Age: ");
                String age = sc.nextLine();

                System.out.print("Enter Course: ");
                String course = sc.nextLine();

                bw.write(id + "," + name + "," + age + "," + course);
            }

            bw.newLine();
            bw.close();

            System.out.println("Student record added successfully.");

        } catch (IOException e) {
            System.out.println("File writing error!");
        }
    }

    static void displayStudents() {
        try {
            BufferedReader br = new BufferedReader(new FileReader(FILE_NAME));
            String line;

            System.out.println("\nID\tName\tAge\tCourse");
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                System.out.println(data[0] + "\t" + data[1] + "\t" + data[2] + "\t" + data[3]);
            }
            br.close();

        } catch (IOException e) {
            System.out.println("File reading error!");
        }
    }

    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            int choice;

            do {
                System.out.println("\n1. Add Student");
                System.out.println("2. Display Students");
                System.out.println("3. Exit");
                System.out.print("Enter choice: ");
                choice = sc.nextInt();
                sc.nextLine(); // clear buffer

                switch (choice) {
                    case 1:
                        addStudent();
                        break;
                    case 2:
                        displayStudents();
                        break;
                    case 3:
                        System.out.println("Program exited.");
                        break;
                    default:
                        System.out.println("Invalid choice!");
                }
            } while (choice != 3);
        }
    }
}


