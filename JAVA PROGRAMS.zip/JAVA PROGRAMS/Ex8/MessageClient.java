import java.io.*;
import java.net.*;

public class MessageClient {
    public static void main(String[] args) throws IOException {
        String serverIP = "127.0.0.1"; // Change to server IP if on another system
        int port = 12345;

        Socket socket = new Socket(serverIP, port);
        System.out.println("Connected to server");

        // Send message
        PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
        out.println("Hello from the client!");

        // Receive reply
        BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        String serverReply = in.readLine();
        System.out.println("Reply from server: " + serverReply);

        // Close connections
        in.close();
        out.close();
        socket.close();
    }
}
