import java.sql.*;
public class SQLiteApp {
    public static void main(String[] args) {
        // SQLite database file 
        String url = "jdbc:sqlite:sampledb.sqlite";

        try {
            // Connect to SQLite 
            Connection conn = DriverManager.getConnection(url);
            System.out.println("✅ Connected to SQLite!");

            Statement stmt = conn.createStatement();

            // Create table
            String createTable = "CREATE TABLE IF NOT EXISTS employees (id INTEGER PRIMARY KEY, name TEXT, salary REAL)";
            stmt.execute(createTable);

            // Insert sample data
            String insert = "INSERT INTO employees (id, name, salary) VALUES (1, 'Alice', 50000)";
            stmt.executeUpdate(insert);

            // Read & display data
            ResultSet rs = stmt.executeQuery("SELECT * FROM employees");
            System.out.println("🧾 Employee Data:");
            while (rs.next()) {
                System.out.printf("ID: %d | Name: %s | Salary: %.2f\n",
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getDouble("salary"));
            }

            rs.close();
            stmt.close();
            conn.close();
            System.out.println("🔚 Connectioncd closed.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

